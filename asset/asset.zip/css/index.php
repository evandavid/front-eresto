<!-- File ini digunakan untuk redirect ke halaman utama eresto, karena halaman yg bersangkutan HARAM untuk diakses -->
<script type="text/javascript">location.href="../"</script>